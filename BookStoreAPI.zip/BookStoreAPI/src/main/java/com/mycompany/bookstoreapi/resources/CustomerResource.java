/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resources;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.*;
import com.mycompany.bookstoreapi.DAO.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/customer")
public class CustomerResource {

    CustomerDAO customerDAO = new CustomerDAO();
    //added for exception
    private static final Logger logger
            = LoggerFactory.getLogger(CustomerResource.class);

//get
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Customer> getAllCustomers() {
        //added for exception
        logger.info("GET request for all customers");
        return customerDAO.getAllCustomers();
    }

// get by id
    @GET
    @Path("/{customerId}")
    @Produces(MediaType.APPLICATION_JSON)

    public Customer getCustomerById(@PathParam("customerId") int customerId) {

        //added for exception
        logger.info("GET request to retrive a customer by id:{}", customerId);
        return (Customer) customerDAO.getCustomersById(customerId);

    }

//post
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addCustomer(Customer customer) {
        logger.info("new customer added with ID:", customer.getId());
        customerDAO.addCustomer(customer);
    }

//put
    @PUT
    @Path("/{customerId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateBook(@PathParam("customerId") int customerID, Customer updatedCustomer) {
        logger.info("customer updated with ID:", customerID);
        Customer existingCustomer = customerDAO.getCustomersById(customerID);
        if (existingCustomer != null) {
            updatedCustomer.setId(customerID);
            customerDAO.updateCustomer(updatedCustomer);
        }
    }

//delete
    @DELETE
    @Path("/{customerId}")
    public void deleteCustomer(@PathParam("customerId") int customerId) {
        logger.info("customer deleted with ID:", customerId);
        customerDAO.deleteCustomer(customerId);
    }
}
