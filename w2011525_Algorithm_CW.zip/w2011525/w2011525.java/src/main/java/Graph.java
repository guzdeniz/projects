/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author guzde
 */
import java.io.*;
import java.util.*;

public class Graph {

    int V;
    List<Edge>[] adj;

    @SuppressWarnings("unchecked")
    public Graph(int V) {
        this.V = V;
        adj = new List[V];
        for (int i = 0; i < V; i++) {
            adj[i] = new ArrayList<>();
        }
    }

    public void addEdge(int u, int v, long capacity) {
        adj[u].add(new Edge(v, capacity, adj[v].size()));
        adj[v].add(new Edge(u, 0, adj[u].size() - 1));
    }

    private boolean bfs(int source, int sink, int[] parent, Edge[] parentEdge) {
        Arrays.fill(parent, -1);
        parent[source] = source;
        Queue<Integer> q = new LinkedList<>();
        q.add(source);

        while (!q.isEmpty()) {
            int u = q.poll();
            for (Edge e : adj[u]) {
                if (parent[e.destinationVertex] == -1 && e.capacity - e.flow > 0) {
                    parent[e.destinationVertex] = u;
                    parentEdge[e.destinationVertex] = e;
                    q.add(e.destinationVertex);
                }
            }
        }
        return parent[sink] != -1;
    }

    private void printPath(int sink, int[] parent, Edge[] parentEdge, long bottleneck) {
        List<Integer> path = new ArrayList<>();
        int v = sink;
        while (v != parent[v]) {
            path.add(v);
            v = parent[v];
            if (v < 0 || v >= V) {
                System.out.println("Error. Invalid parent vertex " + v);
                return;
            }
        }
        path.add(v);
        if (v != 0) {
            System.out.println("Error: Path does not start at source (0), starts at " + v);
            return;
        }
        Collections.reverse(path);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.size(); i++) {
            sb.append(path.get(i));
            if (i < path.size() - 1) {
                sb.append(" -> ");
            }
        }
        System.out.println(sb);
    }

    public long maxFlow(int source, int sink) {
        if (source != 0) {
            System.out.println("Error: Source must be 0, got " + source);
            return 0;
        }

        long totalFlow = 0;
        int[] parent = new int[V];
        Edge[] parentEdge = new Edge[V];
        int iteration = 0;

        System.out.println("Computing Max Flow with Edmonds-Karp Algorithm:");
        System.out.println("---------------------------------------------");

        while (bfs(source, sink, parent, parentEdge)) {
            iteration++;

            long bottleneck = Long.MAX_VALUE;
            for (int v = sink; v != source; v = parent[v]) {
                Edge e = parentEdge[v];
                bottleneck = Math.min(bottleneck, e.capacity - e.flow);
            }

            for (int v = sink; v != source; v = parent[v]) {
                Edge e = parentEdge[v];
                e.flow += bottleneck;
                adj[e.destinationVertex].get(e.reverse).flow -= bottleneck;
            }

            totalFlow += bottleneck;

            System.out.printf("Iteration %d: Added flow = %d, current total flow = %d%n",
                    iteration, bottleneck, totalFlow);
            System.out.print("Path: ");
            printPath(sink, parent, parentEdge, bottleneck);
            System.out.println();
        }

        System.out.println("----------=----------------------------------");
        System.out.printf("Final Max Flow: %d (achieved in %d iterations)%n", totalFlow, iteration);

        return totalFlow;
    }
}
