/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author guzde
 */

// Name: Guzdeniz
// Surname:Guzeloglu
// Student ID:w2011525
import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        String fileName = "test2"; // Please paste your file's name here to test the program.
        BufferedReader br;

        try {
            br = new BufferedReader(new FileReader(fileName));
        } catch (FileNotFoundException e) {
            System.out.println("Error: File " + fileName + " not found");
            return;
        }

        try {
            String line = br.readLine();
            if (line == null || line.trim().isEmpty()) {
                System.out.println("Max Flow: 0 (empty input)");
                br.close();
                return;
            }

            int V = Integer.parseInt(line.trim().split("\\s+")[0]);
            if (V <= 0) {
                throw new NumberFormatException();
            }

            Graph flowGraph = new Graph(V);

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.trim().split("\\s+");
                try {
                    int u = Integer.parseInt(parts[0]);
                    int v = Integer.parseInt(parts[1]);
                    long cap = Long.parseLong(parts[2]);
                    if (u < 0 || u >= V || v < 0 || v >= V) {
                        System.out.println("Error: Invalid vertex in edge " + u + " -> " + v);
                        continue;
                    }
                    if (cap < 0) {
                        System.out.println("Error: Negative capacity in edge " + u + " -> " + v);
                        continue;
                    }
                    flowGraph.addEdge(u, v, cap);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    System.out.println("Error: Invalid edge format: " + line);
                }
            }

            flowGraph.maxFlow(0, V - 1);
            br.close();

        } catch (IOException | NumberFormatException e) {
            System.out.println("Error: Invalid input or I/O exception occurred.");

        }
    }
}
