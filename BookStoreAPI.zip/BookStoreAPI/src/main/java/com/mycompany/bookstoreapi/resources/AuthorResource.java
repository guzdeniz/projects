/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resources;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.*;
import com.mycompany.bookstoreapi.DAO.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.*;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/authors")
public class AuthorResource {

    BookDAO bookDAO = new BookDAO();
    AuthorDAO authorDAO = new AuthorDAO();

    //added for exception
    private static final Logger logger
            = LoggerFactory.getLogger(AuthorResource.class);

//get
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Author> getAllAuthors() {
        //added for exception
        logger.info("GET request for all authors");
        return authorDAO.getAllAuthors();
    }

// get by id
    @GET
    @Path("/{authorId}")
    @Produces(MediaType.APPLICATION_JSON)

    public Author getAuthorById(@PathParam("authorId") int authorId) {

        //added for exception
        logger.info("GET request to retrieve authors by ID:", authorId);
        return (Author) authorDAO.getAuthorsById(authorId);

    }

    @GET
    @Path("/{authorId}/books")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getBooksByAuthorId(@PathParam("authorId") int authorId) {

        //added for exception
        logger.info("GET request to retrieve books by authorId", authorId);
        return authorDAO.getBooksByAuthorId(authorId);
    }

//post
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addAuthor(Author author) {
        //added for exception
        logger.info("new author added", author.getId());
        authorDAO.addAuthor(author);
    }

//put
    @PUT
    @Path("/{authorId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateAuthor(@PathParam("authorId") int authorID, Author updatedAuthor) {
        Author existingAuthor = authorDAO.getAuthorsById(authorID);
        //added for exception
        logger.info("author updated with ID.", authorID);
        if (existingAuthor != null) {
            updatedAuthor.setId(authorID);
            authorDAO.updateAuthor(updatedAuthor);
        }
    }

//delete
    @DELETE
    @Path("/{authorId}")
    public void deleteAuthor(@PathParam("authorId") int authorId) {
        //added for exception
        logger.info("author deleted with Id", authorId);
        authorDAO.deleteAuthor(authorId);
    }

}
