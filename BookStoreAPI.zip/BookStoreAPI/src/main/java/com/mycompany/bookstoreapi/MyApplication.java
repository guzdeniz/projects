/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.resources.*;
import com.mycompany.bookstoreapi.BookStoreAPIResource;
import com.mycompany.bookstoreapi.exceptions.*;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@ApplicationPath("rest")
public class MyApplication extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<>();
        classes.add(BookStoreAPIResource.class);
        classes.add(BookResource.class);
        classes.add(AuthorResource.class);
        classes.add(CartResource.class);
        classes.add(CustomerResource.class);
        classes.add(OrderResource.class);
        
        //mapper
        
        classes.add(BookNotFoundExceptionMapper.class);
        classes.add(AuthorNotFoundExceptionMapper.class);
        classes.add(CartNotFoundExceptionMapper.class);
        classes.add(CustomerNotFoundExceptionMapper.class);
        classes.add(InvalidInputExceptionMapper.class);
        classes.add(OutOfStockExceptionMapper.class);

        return classes;
    }
}
