/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resources;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.*;
import com.mycompany.bookstoreapi.DAO.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/customer/{customerId}/cart")
public class CartResource {

    CartItemDAO cartItemDAO = new CartItemDAO();
    //added for exception
    private static final Logger logger
            = LoggerFactory.getLogger(CartResource.class);

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<CartItem> getCartItems(@PathParam("customerId") int customerId) {
        //added for exception
        logger.info("GET request for all items in cart");
        return cartItemDAO.getCartItems(customerId);
    }

    @POST
    @Path("/item")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addCartItem(@PathParam("customerId") int customerId, CartItem item) {
        //added for exception

        logger.info("new item added.", customerId, item);
        cartItemDAO.addCartItem(customerId, item);
    }

    @PUT
    @Path("/item/{bookId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateCartItem(@PathParam("customerId") int customerId,
            @PathParam("bookId") int bookId,
            CartItem updatedItem) {
        //added for exception

        logger.info(" item updated with ID:", customerId, bookId, updatedItem);
        updatedItem.setBookId(bookId);
        cartItemDAO.updateCartItem(customerId, bookId, updatedItem);
    }

    @DELETE
    @Path("/item/{bookId}")
    public void deleteCartItem(@PathParam("customerId") int customerId,
            @PathParam("bookId") int bookId) {
        //added for exception

        logger.info("item deleted with ID:", bookId, customerId);

        cartItemDAO.deleteCartItem(customerId, bookId);
    }
}
