/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.DAO;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.Book;
import com.mycompany.bookstoreapi.models.Author;
import java.util.*;

public class AuthorDAO {

    private static List<Author> authors = new ArrayList<>();

    static {
        authors.add(new Author(1, "jhon", "biography"));
        authors.add(new Author(2, "max", "biography 2"));

    }

    // as part of the CRUD operations for reading authors
    public List<Author> getAllAuthors() {
        return authors;
    }
//getting authors by id

    public Author getAuthorsById(int id) {
        for (Author author : authors) {
            if (author.getId() == id) {
                return author;
            }

        }

        return null;
    }
//adding authors

    public void addAuthor(Author author) {
        int newUserId = getNextUserId();

        author.setId(newUserId);
        authors.add(author);
    }

    //updating authors
    public void updateAuthor(Author updatedAuthor) {
        for (int i = 0; i < authors.size(); i++) {
            Author author = authors.get(i);

            if (author.getId() == updatedAuthor.getId()) {
                authors.set(i, updatedAuthor);

                System.out.println("author is updated" + updatedAuthor);
                return;
            }
        }
    }

    //deleting authors
    public void deleteAuthor(int id) {
        authors.removeIf(author -> author.getId() == id);
    }

    public int getNextUserId() {
        int maxUserId = Integer.MIN_VALUE;
        for (Author author : authors) {
            int userId = author.getId();
            if (userId > maxUserId) {
                maxUserId = userId;
            }

        }
        return maxUserId + 1;

    }

    //getting authors by book 
    public List<Book> getBooksByAuthorId(int authorId) {
        List<Book> booksByAuthor = new ArrayList<>();
        BookDAO bookDAO = new BookDAO();

        for (Book book : bookDAO.getAllBooks()) {
            if (book.getAuthorId() == authorId) {
                booksByAuthor.add(book);
            }
        }

        return booksByAuthor;
    }

}
