/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resources;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.*;
import com.mycompany.bookstoreapi.DAO.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.*;
import com.mycompany.bookstoreapi.exceptions.BookNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Path("/books")
public class BookResource {

    BookDAO bookDAO = new BookDAO();
    AuthorDAO authorDAO = new AuthorDAO();

//added for exception
    private static final Logger logger
            = LoggerFactory.getLogger(BookResource.class);

//get
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getAllBooks() {
        //added for exception
        logger.info("GET request for all books");
        return bookDAO.getAllBooks();
    }

// get by id
    @GET
    @Path("/{bookId}")
    @Produces(MediaType.APPLICATION_JSON)

    public Book getBookById(@PathParam("bookId") int bookId) {
        //added for exception
        logger.info("GET request to retrive a book by id:{}", bookId);
        return (Book) bookDAO.getBooksById(bookId);

    }

//post
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addBook(Book book) {
        //added for exception
        logger.info("new book added with ID:", book.getId());
        bookDAO.addBook(book);
    }

//put
    @PUT
    @Path("/{bookId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateBook(@PathParam("bookId") int bookID, Book updatedBook) {

        logger.info("book updated with ID:", bookID);
        Book existingBook = bookDAO.getBooksById(bookID);
        if (existingBook != null) {
            updatedBook.setId(bookID);
            bookDAO.updateBook(updatedBook);
        }
    }

//delete
    @DELETE
    @Path("/{bookId}")
    public void deleteBook(@PathParam("bookId") int bookId) {
        logger.info("book deleted with ID:", bookId);
        bookDAO.deleteBook(bookId);
    }

}
