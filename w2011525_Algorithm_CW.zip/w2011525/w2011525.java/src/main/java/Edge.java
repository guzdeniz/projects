/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author guzde
 */

public class Edge {
    int destinationVertex, reverse;
    long capacity, flow;

    public Edge(int destinationVertex, long capacity, int reverse) {
        this.destinationVertex = destinationVertex;
        this.capacity = capacity;
        this.reverse = reverse;
        this.flow = 0;
    }
}

