/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.DAO;

/**
 *
 * @author guzde
 */
import java.util.*;
import com.mycompany.bookstoreapi.models.CartItem;

public class CartItemDAO {

    // key = customerId, value = list of CartItem
    private static Map<Integer, List<CartItem>> customerCarts = new HashMap<>();

    

    // getting all items for a customers cart
    public List<CartItem> getCartItems(int customerId) {
        return customerCarts.getOrDefault(customerId, new ArrayList<>());
    }

    // add a cart item for a customer
    public void addCartItem(int customerId, CartItem cartItem) {
        List<CartItem> cart = customerCarts.getOrDefault(customerId, new ArrayList<>());

        // Check if item already exists, then update quantity instead
        for (CartItem item : cart) {
            if (item.getBookId() == cartItem.getBookId()) {
                item.setQuantity(item.getQuantity() + cartItem.getQuantity());
                customerCarts.put(customerId, cart);
                return;
            }
        }

        cart.add(cartItem);
        customerCarts.put(customerId, cart);
    }

    // updating quantity of a specific book in customers cart
    public void updateCartItem(int customerId, int bookId, CartItem updatedItem) {
        List<CartItem> cart = customerCarts.getOrDefault(customerId, new ArrayList<>());

        for (int i = 0; i < cart.size(); i++) {
            if (cart.get(i).getBookId() == bookId) {
                cart.set(i, updatedItem);
                break;
            }
        }

        customerCarts.put(customerId, cart);
    }

    // deleting specific book from a customers cart
    public void deleteCartItem(int customerId, int bookId) {
        List<CartItem> cart = customerCarts.getOrDefault(customerId, new ArrayList<>());
        cart.removeIf(item -> item.getBookId() == bookId);
        customerCarts.put(customerId, cart);
    }
}
