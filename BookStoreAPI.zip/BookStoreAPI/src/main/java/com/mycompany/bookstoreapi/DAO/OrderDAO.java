/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.DAO;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.Order;
import com.mycompany.bookstoreapi.models.CartItem;
import java.util.*;

public class OrderDAO {

    private static Map<Integer, List<Order>> customerOrders = new HashMap<>();
    private static int currentOrderId = 1;

    // creating order from cart 
    public Order createOrder(int customerId, List<CartItem> cartItems, double totalAmount) {
        int orderDate = (int)(System.currentTimeMillis() / 1000); // Unix timestamp

        Order newOrder = new Order(currentOrderId++, customerId, cartItems, totalAmount, orderDate);

        List<Order> orders = customerOrders.getOrDefault(customerId, new ArrayList<>());
        orders.add(newOrder);
        customerOrders.put(customerId, orders);

        return newOrder;
    }

    // getting all the orders for a customer
    public List<Order> getOrdersByCustomerId(int customerId) {
        return customerOrders.getOrDefault(customerId, new ArrayList<>());
    }

    // getting specific order
    public Order getOrderById(int customerId, int orderId) {
        List<Order> orders = customerOrders.get(customerId);
        if (orders != null) {
            for (Order order : orders) {
                if (order.getId() == orderId) {
                    return order;
                }
            }
        }
        return null;
    }
}