/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.DAO;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.*;
import java.util.*;

public class CustomerDAO {

    private static List<Customer> customers = new ArrayList<>();

    static {
        customers.add(new Customer(1, "guzdeniz", "guzdeniz@gmail.com", "deniz123"));
        customers.add(new Customer(2, "deniz", "guzdeniz2004@gmail.com", "guzdeniz123"));

    }

    // as part of the CRUD operations for reading Customers
    public List<Customer> getAllCustomers() {
        return customers;
    }
//getting customer by id

    public Customer getCustomersById(int id) {
        for (Customer customer : customers) {
            if (customer.getId() == id) {
                return customer;
            }

        }

        return null;
    }
//adding customer

    public void addCustomer(Customer customer) {
        int newUserId = getNextUserId();

        customer.setId(newUserId);
        customers.add(customer);
    }

    //updating customer
    public void updateCustomer(Customer updatedCustomer) {
        for (int i = 0; i < customers.size(); i++) {
            Customer customer = customers.get(i);

            if (customer.getId() == updatedCustomer.getId()) {
                customers.set(i, updatedCustomer);

                System.out.println("Customer is updated" + updatedCustomer);
                return;
            }
        }
    }

    //deleting customer
    public void deleteCustomer(int id) {
        customers.removeIf(customer -> customer.getId() == id);
    }

    public int getNextUserId() {
        int maxUserId = Integer.MIN_VALUE;
        for (Customer customer : customers) {
            int userId = customer.getId();
            if (userId > maxUserId) {
                maxUserId = userId;
            }

        }
        return maxUserId + 1;

    }

}
