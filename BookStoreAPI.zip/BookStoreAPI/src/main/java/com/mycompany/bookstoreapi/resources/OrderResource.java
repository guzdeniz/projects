/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resources;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.DAO.CartItemDAO;
import com.mycompany.bookstoreapi.DAO.OrderDAO;
import com.mycompany.bookstoreapi.models.CartItem;
import com.mycompany.bookstoreapi.models.Order;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/customer/{customerId}/order")
public class OrderResource {

    private OrderDAO orderDAO = new OrderDAO();
    private CartItemDAO cartItemDAO = new CartItemDAO();

    // POST /customer/{customerId}/order
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response placeOrder(@PathParam("customerId") int customerId, Order orderFromClient) {
        List<CartItem> cartItems = cartItemDAO.getCartItems(customerId);

        if (cartItems.isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("cart is empty. You cannot place order.")
                    .build();

        }

        // Remove items with invalid bookId or quantity 0
        cartItems.removeIf(item -> item.getBookId() <= 0 || item.getQuantity() <= 0);

        if (cartItems.isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Cart is empty or contains invalid items. Cannot place order.")
                    .build();
        }

        Order newOrder = orderDAO.createOrder(customerId, cartItems, orderFromClient.getTotalAmount());
        return Response.status(Response.Status.CREATED).entity(newOrder).build();
    }

    // GET /customer/{customerId}/order
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Order> getAllOrders(@PathParam("customerId") int customerId) {
        return orderDAO.getOrdersByCustomerId(customerId);
    }

    // GET /customer/{customerId}/order/{orderId}
    @GET
    @Path("/{orderId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOrderById(@PathParam("customerId") int customerId,
            @PathParam("orderId") int orderId) {
        Order order = orderDAO.getOrderById(customerId, orderId);
        if (order != null) {
            return Response.ok(order).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).entity("order not found").build();
        }
    }
}
