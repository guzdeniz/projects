/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.DAO;

/**
 *
 * @author guzde
 */
import com.mycompany.bookstoreapi.models.Book;
import java.util.*;

public class BookDAO {

    private static List<Book> books = new ArrayList<>();

    static {
        books.add(new Book(1, "The Lord of the Rings", 1,
                "978-0-618-05326-7", 1954, 20.99, 100));
        books.add(new Book(2, "The Lord of the Rings 2", 2,
                "978-0-618-05326-8", 1955, 21.99, 101));

    }

    // as part of the CRUD operations for reading books
    public List<Book> getAllBooks() {
        return books;
    }

    //getting books by id
    public Book getBooksById(int id) {
        for (Book book : books) {
            if (book.getId() == id) {
                return book;
            }

        }

        return null;
    }

    //adding book
    public void addBook(Book book) {
        int newUserId = getNextUserId();

        book.setId(newUserId);
        books.add(book);
    }

    //updating book
    public void updateBook(Book updatedBook) {
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);

            if (book.getId() == updatedBook.getId()) {
                books.set(i, updatedBook);

                System.out.println("book is updated" + updatedBook);
                return;
            }
        }
    }

    //deleting book
    public void deleteBook(int id) {
        books.removeIf(book -> book.getId() == id);
    }

    public int getNextUserId() {
        int maxUserId = Integer.MIN_VALUE;
        for (Book book : books) {
            int userId = book.getId();
            if (userId > maxUserId) {
                maxUserId = userId;
            }

        }
        return maxUserId + 1;

    }
}
