/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.w2011525_planemanagment;

/**
 *
 * @author guzde
 */
import java.util.ArrayList;
import java.util.Scanner;

public class W2011525_PlaneManagment {

    public static void main(String[] args) {
        System.out.println("Welcome to the Plane managment Application");
        Scanner input = new Scanner(System.in);

        String[][] seats = {
            {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
            {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
            {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"},
            {"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"}
        };
        System.out.println("******************************");
        System.out.println("+       MENU OPTIONS        +");
        System.out.println("******************************");
        System.out.println("1) Buy a seat");
        System.out.println("2) Cancel a seat");
        System.out.println("3) Find first available seat");
        System.out.println("4) Show seating plan");
        System.out.println("5) Print tickets information and total sales");
        System.out.println("6) Search ticket");
        System.out.println("0) Quit");
        System.out.println("******************************");
        boolean exit = false;

        while (!exit) {

            System.out.println("Please select and option:");
            String option = input.next();

            switch (option) {
                case "1":
                    buySeat(seats);
                    break;
                case "2":
                    cancelSeat(seats);
                    break;
                case "3":
                    findFirstSeat(seats);
                    break;
                case "4":
                    showSeatingPlan(seats);
                    break;
                    

                case "0":
                    System.out.println("Have a nice Flight.");
                    exit = true;
                    break;

                default:
                    System.out.println("Wrong option. Please try again.");

            }
        }

    }

    private static void buySeat(String[][] seats) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please select your row");
        String row = input.next();
        System.out.println("Please select your seat number");
        int seatNumber = input.nextInt();
        if (row.equals("A")) {

            if (seatNumber >= 1 && seatNumber <= 14) {
                int i = seatNumber - 1;
                if (seats[0][i] == "1") {
                    System.out.println("This seat has been booked.Try another seat.");

                } else {

                    seats[0][i] = "1";
                    System.out.println("Your ticket is booked.");
                }
            } else {

                System.out.println("Invalid value.");

            }
        } else if (row.equals("B")) {

            if (seatNumber >= 1 && seatNumber <= 12) {
                int i = seatNumber - 1;
                if (seats[1][i] == "1") {
                    System.out.println("This seat has been booked.Try another seat.");

                } else {

                    seats[1][i] = "1";
                    System.out.println("Your ticket is booked.");
                }
            } else {

                System.out.println("Invalid value.");
            }
        } else if (row.equals("C")) {

            if (seatNumber >= 1 && seatNumber <= 12) {
                int i = seatNumber - 1;
                if (seats[2][i] == "1") {
                    System.out.println("This seat has been booked.Try another seat.");

                } else {

                    seats[2][i] = "1";
                    System.out.println("Your ticket is booked.");
                }
            } else {

                System.out.println("Invalid value.");
            }
        } else if (row.equals("D")) {
            if (seatNumber >= 1 && seatNumber <= 14) {
                int i = seatNumber - 1;
                if (seats[3][i] == "1") {
                    System.out.println("This seat has been booked.Try another seat.");

                } else {

                    seats[3][i] = "1";
                    System.out.println("Your ticket is booked.");
                }
            } else {

                System.out.println("Invalid value.");

            }
        } else {
            System.out.println("Invalid value.");

        }

    }

    private static void cancelSeat(String[][] seats) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please select your row");
        String row = input.next();
        System.out.println("Please select your seat number");
        int seatNumber = input.nextInt();

        if (row.equals("A")) {

            if (seatNumber >= 1 && seatNumber <= 14) {
                int i = seatNumber - 1;
                if (seats[0][i] == "1") {
                    System.out.println("This seat has been canceled.");
                    seats[0][i] = "0";
                } else {

                    System.out.println("Your seat is empty.");
                }
            } else {

                System.out.println("Invalid value.");

            }
        } else if (row.equals("B")) {

            if (seatNumber >= 1 && seatNumber <= 12) {
                int i = seatNumber - 1;
                if (seats[0][i] == "1") {
                    System.out.println("This seat has been canceled.");
                    seats[1][i] = "0";
                } else {

                    System.out.println("Your seat is empty.");
                }
            } else {

                System.out.println("Invalid value.");
            }
        } else if (row.equals("C")) {

            if (seatNumber >= 1 && seatNumber <= 12) {
                int i = seatNumber - 1;
                if (seats[0][i] == "1") {
                    System.out.println("This seat has been canceled.");
                    seats[2][i] = "0";
                } else {

                    System.out.println("Your seat is empty.");
                }
            } else {

                System.out.println("Invalid value.");
            }
        } else if (row.equals("D")) {
            if (seatNumber >= 1 && seatNumber <= 14) {
                int i = seatNumber - 1;
                if (seats[0][i] == "1") {
                    System.out.println("This seat has been canceled.");
                    seats[3][i] = "0";
                } else {

                    System.out.println("Your seat is empty.");
                }
            } else {

                System.out.println("Invalid value.");

            }
        } else {
            System.out.println("Invalid value.");

        }

    }

    private static void findFirstSeat(String[][] seats) {

        String search = "0";
        int index = 0;
        int index1 = 0;
        while (index1 < seats.length) {
            while (index < seats[index1].length && seats[index1][index] != search) {
                index++;
            }
            if (index == seats[index1].length) {
                index1++;
                index = 0;

            } else {
                index = index + 1;
                if (index1 == 0) {
                    System.out.println("First available seat is A" + index);
                    return;
                } else if (index1 == 1) {

                    System.out.println("First available seat is B" + index);
                    return;

                } else if (index1 == 2) {
                    System.out.println("First available seat is C" + index);
                    return;
                } else if (index1 == 3) {
                    System.out.println("First available seat is D" + index);
                    return;
                } else {
                    System.out.println("Invalid value.");
                }

            }
        }

    }

    private static void showSeatingPlan(String[][] seats) {

        String search = "0";
        String search1 = "1";

        int index = 0;
        int index1 = 0;
        while (index1 < seats.length) {
            index = 0;
            while (index < seats[index1].length && seats[index1][index] != search) {
                index++;
            }
            if (index == seats[index1].length) {
                index1++;
                index = 0;

            } else {
                seats[index1][index] = "O";

            }

            index = 0;

            while (index < seats[index1].length && seats[index1][index] != search1) {
                index++;

            }
            if (index == seats[index1].length) {
                index1++;
                index = 0;

            } else {
                seats[index1][index] = "X";

            }

        }
        for (int x = 0; x <= 13; x++) {
            System.out.print(seats[0][x]);
        }
        System.out.println("");
        for (int x = 0; x <= 11; x++) {
            System.out.print(seats[1][x]);
        }
        System.out.println("");
        System.out.println("");
        for (int x = 0; x <= 11; x++) {
            System.out.print(seats[2][x]);
        }
        System.out.println("");
        for (int x = 0; x <= 13; x++) {
            System.out.print(seats[3][x]);
        }
        System.out.println("");
    }
    

}
